<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.templates') ); ?>

<?php $__env->startSection('content'); ?>
<div class="main_container">
    <div class="col">
    <div class="row mb-4">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>
                        <i class="fa fas fa-tachometer-alt"></i> <?php echo app('translator')->get('navs.frontend.templates'); ?>
                        <a href="<?php echo e(route('frontend.guide.front.categories')); ?>" class="btn btn-primary justify-content-end" style="float: right">Back to Categories</a>
                    </strong>
                </div><!--card-header-->

                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-2 bg-light text-center">
                            <div style="background-image: url(<?php echo e(asset($template->getMedia('guide_templates_banner')->first()->getUrl('thumb'))); ?>)">
                                <img class="card-img-top rounded-circle img-thumbnail profile_pic mt-4" style="height: 100px;" src="<?php echo e(asset($template->getMedia('guide_templates_icon')->first()->getUrl('thumb'))); ?>" alt="<?php echo e($template->title); ?>">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">
                                    <?php echo e($template->title); ?><br/>
                                </h4>

                                <p class="card-text">
                                    <?php echo e($template->description); ?>

                                </p>
                                <a href="#" class="btn btn-light">Learn More</a>
                            <a href="<?php echo e(route('frontend.auth.register')); ?>" class="btn btn-primary">Choose</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                    </div><!--row-->
                </div> <!-- card-body -->
            </div><!-- card -->
        </div><!-- row -->
    </div><!-- row -->
</div> <!-- col end -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/template/listbycategory.blade.php ENDPATH**/ ?>
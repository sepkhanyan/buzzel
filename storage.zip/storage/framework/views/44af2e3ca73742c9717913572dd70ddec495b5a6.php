<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.categories') ); ?>

<?php $__env->startSection('content'); ?>
<div class="main_container">
    <div class="col">
    <div class="row mb-4">
        <div class="col">
            <div class="card">
                <div class="card-header">
                    <strong>
                        <i class="fa fas fa-tachometer-alt"></i> <?php echo app('translator')->get('navs.frontend.categories'); ?>
                    </strong>
                </div><!--card-header-->

                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mb-2 bg-light text-center">
                        <img class="card-img-top rounded-circle img-thumbnail profile_pic mt-4" style="height: 100px;" src="<?php echo e(asset($category->getMedia('guide_categories')->first()->getUrl('thumb'))); ?>" alt="<?php echo e($category->title); ?>">

                            <div class="card-body">
                                <h4 class="card-title">
                                    <?php echo e($category->title); ?><br/>
                                </h4>

                                <p class="card-text">

                          <?php echo e($category->description); ?>

                                </p>
                                <a href="<?php echo e(route('frontend.guide.front.category.template', $category)); ?>" class="btn btn-primary">Select & View Template</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                    </div><!--row-->
                </div> <!-- card-body -->
            </div><!-- card -->
        </div><!-- row -->
    </div><!-- row -->
</div> <!-- col end -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/guide/index.blade.php ENDPATH**/ ?>
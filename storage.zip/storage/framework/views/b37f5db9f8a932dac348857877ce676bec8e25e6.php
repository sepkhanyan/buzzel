<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.dashboard') ); ?>

<?php $__env->startSection('content'); ?>
<div class="main_container">
    <div class="row">
        <div class="col text-center">
            <h3>Dashboard</h3>
        </div>
    </div>
    <div class="row">

        <div class="col-9">
            <div class="col-md-10 order-2 order-sm-1">
                    <pending-guides-component></pending-guides-component>
            </div><!--col-md-8-->
        </div> <!-- col end -->
        <div class="col-3">
            <?php echo $__env->make('frontend.user.guide.partials.dashboard_side_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/user/dashboard.blade.php ENDPATH**/ ?>
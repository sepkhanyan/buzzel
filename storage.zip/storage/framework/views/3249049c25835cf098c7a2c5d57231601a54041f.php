<?php if($widget->active): ?>
    <span class='badge badge-success'><?php echo app('translator')->get('labels.general.active'); ?></span>
<?php else: ?>
    <span class='badge badge-danger'><?php echo app('translator')->get('labels.general.inactive'); ?></span>
<?php endif; ?>
<?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/includes/active.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.dashboard') ); ?>

<?php $__env->startSection('content'); ?>

<chose-guide-details placeholder_image_path="<?php echo e(env('APP_URL')); ?>"></chose-guide-details>    
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.guide_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/user/guide/chose_guide_details.blade.php ENDPATH**/ ?>
<div class="col">
    <div class="table-responsive">
        <table class="table table-hover">

            <tr>
                <th><?php echo app('translator')->get('labels.backend.guides.widgets.tabs.content.overview.icon'); ?></th>
                <td>
                    <div class="mt-2">
                        <img src="<?php echo e(asset($widget->getMedia('guide_widgets_backend')->first()->getUrl('thumb'))); ?>" alt="<?php echo e(ucwords($widget->title)); ?>" class="img-thumbnail">
                    </div>
                </td>
            </tr>

            <tr>
                <th><?php echo app('translator')->get('labels.backend.guides.widgets.tabs.content.overview.title'); ?></th>
                <td><?php echo e($widget->title); ?></td>
            </tr>

            <tr>
                <th><?php echo app('translator')->get('labels.backend.guides.widgets.tabs.content.overview.description'); ?></th>
                <td><?php echo e($widget->description); ?></td>
            </tr>

            <tr>
                <th><?php echo app('translator')->get('labels.backend.guides.widgets.tabs.content.overview.status'); ?></th>
                <td><?php echo $__env->make('backend.guides.widgets.includes.active', ['widget' => $widget], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
            </tr>

        </table>
    </div>
</div><!--table-responsive-->
<?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/show/tabs/overview.blade.php ENDPATH**/ ?>
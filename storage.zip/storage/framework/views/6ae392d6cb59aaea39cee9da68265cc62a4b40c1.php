<?php $__env->startSection('title', __('labels.backend.guides.widgets.widgets') . ' | ' . __('labels.backend.guides.widgets.view')); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    <?php echo app('translator')->get('labels.backend.guides.widgets.widgets'); ?>
                    <small class="text-muted"><?php echo app('translator')->get('labels.backend.guides.widgets.view'); ?></small>
                </h4>
            </div><!--col-->
        </div><!--row-->

        <div class="row mt-4 mb-4">
            <div class="col">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-expanded="true"><i class="fas fa-plug"></i> <?php echo app('translator')->get('labels.backend.guides.widgets.tabs.titles.overview'); ?></a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane active" id="overview" role="tabpanel" aria-expanded="true">
                        <?php echo $__env->make('backend.guides.widgets.show.tabs.overview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div><!--tab-->
                </div><!--tab-content-->
            </div><!--col-->
        </div><!--row-->
    </div><!--card-body-->

    <div class="card-footer">
        <div class="row">
            <div class="col">
                <small class="float-right text-muted">
                    <strong><?php echo app('translator')->get('labels.backend.templates.tabs.content.overview.created_at'); ?>:</strong> <?php echo e(timezone()->convertToLocal($widget->created_at)); ?> (<?php echo e($widget->created_at->diffForHumans()); ?>),
                    <strong><?php echo app('translator')->get('labels.backend.templates.tabs.content.overview.last_updated'); ?>:</strong> <?php echo e(timezone()->convertToLocal($widget->updated_at)); ?> (<?php echo e($widget->updated_at->diffForHumans()); ?>)
                </small>
            </div><!--col-->
        </div><!--row-->
    </div><!--card-footer-->
</div><!--card-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/show.blade.php ENDPATH**/ ?>
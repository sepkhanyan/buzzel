<?php $__env->startSection('title', __('labels.backend.guides.widgets.fields.fields') . ' | ' . __('labels.backend.guides.widgets.fields.create')); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(html()->form('POST', route('admin.guide.templates.widgets.store'))->class('form-horizontal')->acceptsFiles()->open()); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-5">
                    <h4 class="card-title mb-0">
                        <?php echo app('translator')->get('labels.backend.templates.widgets.name'); ?>
                        <small class="text-muted"><?php echo app('translator')->get('labels.backend.templates.widgets.create'); ?></small>
                    </h4>
                </div><!--col-->
            </div><!--row-->

            <hr>
            <?php echo e(html()->hidden('guide_template_id', $template->id)); ?>

            <div class="row mt-4">
                <div class="col">
                    <div class="form-group row">
                        <?php echo e(html()->label(__('validation.attributes.backend.templates.name'))
                            ->class('col-md-2 form-control-label')
                            ->for('template_title')); ?>


                        <div class="col-md-10">
                            <?php echo e(html()->text('template_title')
                                ->value($template->title)
                                ->class('form-control')
                                ->attribute('maxlength', 191)
                                ->required()
                                ->readonly()); ?>

                        </div><!--col-->
                    </div><!--form-group-->

                    <div class="form-group row">
                        <?php echo e(html()->label(__('validation.attributes.backend.templates.select_widgets'))
                            ->class('col-md-2 form-control-label')
                            ->for('categories')); ?>


                        <div class="col-md-10">
                            <?php echo e(html()->select()
                                ->name('widget_id')
                                ->class('form-control')
                                ->options($widgets)
                                ->placeholder(__('validation.attributes.backend.templates.select_widgets'))
                                ->required()
                                ->multiple()); ?>

                        </div><!--col-->
                    </div><!--form-group-->

                </div><!--col-->
            </div><!--row-->
        </div><!--card-body-->

        <div class="card-footer">
            <div class="row">
                <div class="col">
                    <?php echo e(form_cancel(route('admin.guide.templates.widgets', $template), __('buttons.general.cancel'))); ?>

                </div><!--col-->

                <div class="col text-right">
                    <?php echo e(form_submit(__('buttons.general.crud.create'))); ?>

                </div><!--col-->
            </div><!--row-->
        </div><!--card-footer-->
    </div><!--card-->
<?php echo e(html()->form()->close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/templates/widgets/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', app_name() . ' | ' . __('labels.backend.access.users.management')); ?>

<?php $__env->startSection('breadcrumb-links'); ?>
    <?php echo $__env->make('backend.auth.user.includes.breadcrumb-links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('after-style'); ?>
    <?php echo style('vendors/datatables/datatables.min.css'); ?>

    <?php echo style('vendors/datatables/datatables.bootstrap4.css'); ?>

    <?php echo style('vendors/datatables/Responsive-2.2.2/css/responsive.dataTables.min.css'); ?>

    <?php echo style('vendors/datatables/Select-1.3.0/css/select.dataTables.min.css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">

        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    <?php echo e(__('labels.backend.access.users.management')); ?> <small class="text-muted"><?php echo e(__('labels.backend.access.users.active')); ?></small>
                </h4>
            </div><!--col-->

            <div class="col-sm-7">
                <?php echo $__env->make('backend.auth.user.includes.header-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!--col-->
        </div><!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table class="table" id="activeUsers">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.last_name'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.first_name'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.email'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.confirmed'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.roles'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.last_updated'); ?></th>
                            <th><?php echo app('translator')->get('labels.general.actions'); ?></th>
                        </tr>
                        <thead>
                        <tfoot>
                        <tr>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.last_name'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.first_name'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.email'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.confirmed'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.roles'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.access.users.table.last_updated'); ?></th>
                            <th class="non_searchable"><?php echo app('translator')->get('labels.general.actions'); ?></th>

                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <?php echo e(script('vendors/datatables/jquery.dataTables.min.js')); ?>

    <?php echo e(script('vendors/datatables/datatables.min.js')); ?>

    <?php echo e(script('vendors/datatables/dataTables.bootstrap4.min.js')); ?>

    <?php echo e(script('vendors/datatables/Responsive-2.2.2/js/dataTables.responsive.min.js')); ?>

    <?php echo e(script('vendors/datatables/Select-1.3.0/js/dataTables.select.min.js')); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#activeUsers').DataTable({
                order: [[ 0, 'asc' ]],
                responsive: true,
                autoWidth: false,
                processing: true,
                serverSide: true,
                searchable:false,
                ajax: "<?php echo e(route('admin.auth.user.datatable')); ?>",
                columns: [
                    {data: 'last_name', name: 'last_name'},
                    {data: 'first_name', name: 'first_name'},
                    {data: 'email', name: 'email'},
                    {data: 'confirmed', name: 'confirmed'},
                    {data: 'roles_label', name: 'roles_label'},
                    {data: 'updated_at', name: 'updated_at'},
                    {data: 'action', name: 'action', orderable: false, searchable: false}
                ],
                initComplete: function () {
                    this.api().columns().every(function () {
                        var column = this;
                        var columnClass = column.footer().className;
                        if(columnClass != 'non_searchable'){
                            var input = document.createElement("input");
                            $(input).appendTo($(column.footer()).empty())
                                .on('change', function () {
                                    column.search($(this).val(), false, false, true).draw();
                                });
                        }
                    });

                },
                drawCallback: function(){
                    // tooltip
                    $("[data-toggle='tooltip']").tooltip();
                    // Width attribute
                    $('[data-width]').each(function() {
                        $(this).css({
                            width: $(this).data('width')
                        });
                    });

                    // Height attribute
                    $('[data-height]').each(function() {
                        $(this).css({
                            height: $(this).data('height')
                        });
                    });
                }

            });

        });

    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/auth/user/index.blade.php ENDPATH**/ ?>
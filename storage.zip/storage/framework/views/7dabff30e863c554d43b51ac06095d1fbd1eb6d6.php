
    <div class="btn-group btn-group-sm" role="group" aria-label="<?php echo app('translator')->get('labels.backend.guides.widgets.actions'); ?>">
        <a href="<?php echo e(route('admin.guide.widgets.fields', $widget)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.fields'); ?>">
            <i class="fa fa-list" aria-hidden="true"></i>
        </a>
        <a href="<?php echo e(route('admin.guide.widgets.show', $widget)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.view'); ?>" class="btn btn-info">
            <i class="fas fa-eye"></i>
        </a>
        <a href="<?php echo e(route('admin.guide.widgets.edit', $widget)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.edit'); ?>">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('admin.guide.widgets.destroy', $widget)); ?>"
           data-method="delete"
           data-trans-button-cancel="<?php echo app('translator')->get('buttons.general.cancel'); ?>"
           data-trans-button-confirm="<?php echo app('translator')->get('buttons.general.crud.delete'); ?>"
           data-trans-title="<?php echo app('translator')->get('strings.backend.general.are_you_sure'); ?>"
           class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.delete'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </div>

<?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/includes/actions.blade.php ENDPATH**/ ?>
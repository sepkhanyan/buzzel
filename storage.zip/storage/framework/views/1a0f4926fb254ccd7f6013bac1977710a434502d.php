<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.categories') ); ?>

<?php $__env->startSection('content'); ?>
<div class="main_container">
    <router-view></router-view>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.guide_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/guide/vue/index.blade.php ENDPATH**/ ?>
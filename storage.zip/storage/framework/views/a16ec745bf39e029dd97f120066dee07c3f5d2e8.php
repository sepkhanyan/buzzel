<?php if($user->providers->count()): ?>
    <?php $__currentLoopData = $user->providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route( 'admin.auth.user.social.unlink', [$user, $social])); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.backend.access.users.unlink'); ?>" data-method="delete">
            <i class="fab fa-<?php echo e($social->provider); ?>"></i>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <?php echo app('translator')->get('labels.general.none'); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/buzzel_my/resources/views/backend/auth/user/includes/social-buttons.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', app_name() . ' | ' . __('labels.backend.guides.widgets.fields.fields')); ?>

<?php $__env->startPush('after-style'); ?>
    <?php echo style('vendors/datatables/datatables.min.css'); ?>

    <?php echo style('vendors/datatables/datatables.bootstrap4.css'); ?>

    <?php echo style('vendors/datatables/Responsive-2.2.2/css/responsive.dataTables.min.css'); ?>

    <?php echo style('vendors/datatables/Select-1.3.0/css/select.dataTables.min.css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">

        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    <?php echo e(__('labels.backend.guides.widgets.fields.fields')); ?> <small class="text-muted"><?php echo e(__('labels.backend.guides.widgets.fields.active')); ?></small>
                </h4>
            </div><!--col-->

            <div class="col-sm-7">
                <?php echo $__env->make('backend.guides.widgets.fields.includes.header-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!--col-->
        </div><!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get('labels.backend.guides.widgets.fields.table.key'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.guides.widgets.fields.table.description'); ?></th>
                            <th><?php echo app('translator')->get('labels.general.actions'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($field->field_key); ?></td>
                                    <td><?php echo e($field->description); ?></td>
                                    <td><?php echo $__env->make('backend.guides.widgets.fields.includes.actions', ['field' => $field, 'widget' => $widget], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div><!--col-->
        </div><!--row-->
        <div class="row">
            <div class="col-7">
                <div class="float-left">
                    <?php echo $fields->total(); ?> <?php echo e(trans_choice('labels.backend.guides.widgets.fields.table.total', $fields->total())); ?>

                </div>
            </div><!--col-->

            <div class="col-5">
                <div class="float-right">
                    <?php echo $fields->render(); ?>

                </div>
            </div><!--col-->
        </div><!--row-->
    </div><!--card-body-->
</div><!--card-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/fields/index.blade.php ENDPATH**/ ?>
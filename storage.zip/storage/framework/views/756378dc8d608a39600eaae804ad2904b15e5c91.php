<div class="btn-toolbar float-right" role="toolbar" aria-label="<?php echo app('translator')->get('labels.general.toolbar_btn_groups'); ?>">
    <a href="<?php echo e(route('admin.auth.role.create')); ?>" class="btn btn-success ml-1" data-toggle="tooltip" title="<?php echo app('translator')->get('labels.general.create_new'); ?>"><i class="fas fa-plus-circle"></i></a>
</div>
<?php /**PATH /var/www/html/buzzel/resources/views/backend/auth/role/includes/header-buttons.blade.php ENDPATH**/ ?>
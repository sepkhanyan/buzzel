<?php $__env->startSection('title', __('labels.backend.guides.widgets.fields.fields') . ' | ' . __('labels.backend.guides.widgets.fields.edit')); ?>

<?php $__env->startSection('content'); ?>

<?php echo e(html()->modelForm($field, 'PATCH', route('admin.guide.widgets.fields.update',$widget))->class('form-horizontal')->acceptsFiles()->open()); ?>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-5">
                    <h4 class="card-title mb-0">
                        <?php echo app('translator')->get('labels.backend.guides.widgets.fields.fields'); ?>
                        <small class="text-muted"><?php echo app('translator')->get('labels.backend.guides.widgets.fields.edit'); ?></small>
                    </h4>
                </div><!--col-->
            </div><!--row-->

            <hr>
            <?php echo e(html()->hidden('id', $field->id)); ?>

            <?php echo e(html()->hidden('widget_id', $widget->id)); ?>

            <div class="row mt-4">
                <div class="col">
                    <div class="form-group row">
                        <?php echo e(html()->label(__('validation.attributes.backend.guides.widgets.fields.title'))
                            ->class('col-md-2 form-control-label')
                            ->for('field_key')); ?>


                        <div class="col-md-10">
                            <?php echo e(html()->text('field_key')
                                ->class('form-control')
                                ->placeholder(__('validation.attributes.backend.guides.widgets.fields.title'))
                                ->attribute('maxlength', 191)
                                ->required()
                                ->autofocus()); ?>

                        </div><!--col-->
                    </div><!--form-group-->

                    <div class="form-group row">
                        <?php echo e(html()->label(__('validation.attributes.backend.guides.widgets.fields.description'))
                            ->class('col-md-2 form-control-label')
                            ->for('description')); ?>


                        <div class="col-md-10">
                            <?php echo e(html()->textarea('description')
                                ->class('form-control')
                                ->placeholder(__('validation.attributes.backend.guides.widgets.fields.description'))
                                ->required()
                                ->autofocus()); ?>

                        </div><!--col-->
                    </div><!--form-group-->

                </div><!--col-->
            </div><!--row-->
        </div><!--card-body-->

        <div class="card-footer">
            <div class="row">
                <div class="col">
                    <?php echo e(form_cancel(route('admin.guide.widgets.fields', $widget), __('buttons.general.cancel'))); ?>

                </div><!--col-->

                <div class="col text-right">
                    <?php echo e(form_submit(__('buttons.general.crud.update'))); ?>

                </div><!--col-->
            </div><!--row-->
        </div><!--card-footer-->
    </div><!--card-->
<?php echo e(html()->form()->close()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/fields/edit.blade.php ENDPATH**/ ?>
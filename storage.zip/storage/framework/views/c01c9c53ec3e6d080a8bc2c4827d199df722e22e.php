<?php if($role->id !== 1): ?>
    <div class="btn-group btn-group-sm" role="group" aria-label="<?php echo app('translator')->get('labels.backend.access.users.user_actions'); ?>">
        <a href="<?php echo e(route('admin.auth.role.edit', $role)); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.edit'); ?>">
            <i class="fas fa-edit"></i>
        </a>

        <a href="<?php echo e(route('admin.auth.role.destroy', $role)); ?>"
           data-method="delete"
           data-trans-button-cancel="<?php echo app('translator')->get('buttons.general.cancel'); ?>"
           data-trans-button-confirm="<?php echo app('translator')->get('buttons.general.crud.delete'); ?>"
           data-trans-title="<?php echo app('translator')->get('strings.backend.general.are_you_sure'); ?>"
           class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('buttons.general.crud.delete'); ?>">
            <i class="fas fa-trash"></i>
        </a>
    </div>
<?php else: ?>
    N/A
<?php endif; ?>
<?php /**PATH /var/www/html/buzzel/resources/views/backend/auth/role/includes/actions.blade.php ENDPATH**/ ?>
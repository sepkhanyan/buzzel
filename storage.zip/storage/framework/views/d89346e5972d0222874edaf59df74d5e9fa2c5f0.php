<footer class="app-footer">
    <div>
        <strong><?php echo app('translator')->get('labels.general.copyright'); ?> &copy; <?php echo e(date('Y')); ?>

            <a href="#">
                <?php echo app('translator')->get('strings.backend.general.boilerplate_link'); ?>
            </a>
        </strong> <?php echo app('translator')->get('strings.backend.general.all_rights_reserved'); ?>
    </div>

    <div class="ml-auto">Theme by <a href="#">CoreUI</a></div>
</footer><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/includes/footer.blade.php ENDPATH**/ ?>
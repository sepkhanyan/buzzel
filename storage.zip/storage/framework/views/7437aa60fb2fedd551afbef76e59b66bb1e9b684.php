<aside class="aside-menu">

</aside>
<?php /**PATH /var/www/html/buzzel_my/resources/views/backend/includes/aside.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', app_name() . ' | ' . __('navs.frontend.dashboard') ); ?>
<?php $__env->startPush('after-styles'); ?>
    <?php echo e(style('css/frontend/custom.css')); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
        <!-- Main Content  -->
        
        <!-- Main Content  -->

    <guide-component></guide-component>
    <!-- SideBar -->


    <!-- Modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>



    <script type="text/javascript">

        $(document).ready(function(){
            // var grid = new Muuri('.grid', {
            //     dragEnabled: true,
            //     layout: {
            //         fillGaps: true
            //     }
            // });
            // grid.refreshItems().layout();


            $('.datepicker').datepicker();


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/user/guide/build.blade.php ENDPATH**/ ?>
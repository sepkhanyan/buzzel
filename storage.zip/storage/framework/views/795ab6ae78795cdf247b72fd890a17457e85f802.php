<!-- Header -->
<header>
    <div class="logo"><a href="javascript:void(0);">Buzzel</a></div>
    <ul class="leftLinks">
        <li class="navLi dropdown">
            <a class="navLi_a dropdown-toggle" href="#" data-toggle="dropdown">Recents</a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <a class="dropdown-item" href="#">Something else here</a>
            </div>
        </li>

        <li class="navLi dropdown">
            <a class="navLi_a dropdown-toggle" href="#" data-toggle="dropdown">Support</a>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="#">Action</a>
                <a class="dropdown-item" href="#">Another action</a>
                <a class="dropdown-item" href="#">Something else here</a>
            </div>
        </li>
        <?php if(auth()->guard()->check()): ?>
        <li class="navLi"><a href="<?php echo e(route('frontend.user.dashboard')); ?>" class="nav-link <?php echo e(active_class(Route::is('frontend.user.dashboard'))); ?>"><?php echo app('translator')->get('navs.frontend.dashboard'); ?></a></li>
        <?php endif; ?>
    </ul>

    <div class="nav_right">
        <div class="searchHeader">
            <i class="fa fa-search"></i>
            <input type="Search" class="headerSearch" placeholder="Search this guide" />
        </div>

        <div class="HeadNotification headIcons">
            <i class="fa fa-bell-o"></i>
        </div>
        <div class="HeadActivity headIcons">
            <i class="fa fa-cog"></i>
        </div>
        <?php if(auth()->guard()->guest()): ?>
        <div class="nav-item"><a href="<?php echo e(route('frontend.auth.login')); ?>" class="nav-link <?php echo e(active_class(Route::is('frontend.auth.login'))); ?>"><?php echo app('translator')->get('navs.frontend.login'); ?></a></div>

        <?php if(config('access.registration')): ?>
            <div class="nav-item"><a href="<?php echo e(route('frontend.auth.register')); ?>" class="nav-link <?php echo e(active_class(Route::is('frontend.auth.register'))); ?>"><?php echo app('translator')->get('navs.frontend.register'); ?></a></div>
        <?php endif; ?>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <div class="HeadUserInfo dropdown">
                <div class="userinfoRow dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i><span><?php echo e(auth()->user()->full_name); ?></span></div>

                <div class=" dropdown-menu">
                    <div class="infoEmailAdress">
                        <h3><?php echo e(auth()->user()->full_name); ?></h3>
                        <h5><?php echo e(auth()->user()->email); ?></h5>
                    </div>
                    <ul class="HeadMoreLinks">
                        <li><a href="<?php echo e(route('frontend.user.account')); ?>" class="<?php echo e(active_class(Route::is('frontend.user.account'))); ?>"><?php echo app('translator')->get('navs.frontend.user.account'); ?></a></li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view backend')): ?>
                        <li>
                            <a href="<?php echo e(route('admin.dashboard')); ?>" ><?php echo app('translator')->get('navs.frontend.user.administration'); ?></a>
                        </li>
                        <?php endif; ?>
                        <li><a href="javascript:void(0);">Your Purchases</a></li>
                        <li class="spaceNav"></li>
                        <li><a href="javascript:void(0);">Terms of Service</a></li>
                        <li><a href="javascript:void(0);">Privacy Policy</a></li>
                        <li><a href="javascript:void(0);"> <a href="<?php echo e(route('frontend.auth.logout')); ?>"><?php echo app('translator')->get('navs.general.logout'); ?></a></a></li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

    </div>
</header>
<!-- Header -->



<?php /**PATH /var/www/html/buzzel_my/resources/views/frontend/includes/nav.blade.php ENDPATH**/ ?>
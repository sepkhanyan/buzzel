<?php $__env->startSection('title', app_name() . ' | ' . __('labels.backend.templates.admin_templates')); ?>

<?php $__env->startPush('after-style'); ?>
    <?php echo style('vendors/datatables/datatables.min.css'); ?>

    <?php echo style('vendors/datatables/datatables.bootstrap4.css'); ?>

    <?php echo style('vendors/datatables/Responsive-2.2.2/css/responsive.dataTables.min.css'); ?>

    <?php echo style('vendors/datatables/Select-1.3.0/css/select.dataTables.min.css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">

        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    <?php echo e(__('labels.backend.templates.templates')); ?> <small class="text-muted"><?php echo e(__('labels.backend.templates.admin_templates')); ?></small>
                </h4>
            </div><!--col-->

            <div class="col-sm-7">
                <?php echo $__env->make('backend.templates.includes.header-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!--col-->
        </div><!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get('labels.backend.templates.table.icon'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.templates.table.banner'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.templates.table.category'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.templates.table.title'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.templates.table.status'); ?></th>
                            <th><?php echo app('translator')->get('labels.general.actions'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="<?php echo e(asset($template->getMedia('guide_templates_icon')->first()->getUrl('thumb'))); ?>" alt="<?php echo e(ucwords($template->title)); ?>" class="img-thumbnail"></td>
                                    <td><img src="<?php echo e(asset($template->getMedia('guide_templates_banner')->first()->getUrl('thumb'))); ?>" alt="<?php echo e(ucwords($template->title)); ?>" class="img-thumbnail"></td>
                                    <td><?php echo e(ucwords($template->category)); ?></td>
                                    <td><?php echo e(ucwords($template->title)); ?></td>
                                    <td><?php echo $__env->make('backend.templates.includes.active', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                    <td><?php echo $__env->make('backend.templates.includes.actions', ['template' => $template], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div><!--col-->
        </div><!--row-->
        <div class="row">
            <div class="col-7">
                <div class="float-left">
                    <?php echo $templates->total(); ?> <?php echo e(trans_choice('labels.backend.guides.table.total', $templates->total())); ?>

                </div>
            </div><!--col-->

            <div class="col-5">
                <div class="float-right">
                    <?php echo $templates->render(); ?>

                </div>
            </div><!--col-->
        </div><!--row-->
    </div><!--card-body-->
</div><!--card-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/templates/index.blade.php ENDPATH**/ ?>
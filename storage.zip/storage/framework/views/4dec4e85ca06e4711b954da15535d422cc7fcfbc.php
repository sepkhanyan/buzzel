<?php $__env->startSection('title', app_name() . ' | ' . __('labels.backend.guides.widgets.widgets')); ?>


<?php $__env->startPush('after-style'); ?>
    <?php echo style('vendors/datatables/datatables.min.css'); ?>

    <?php echo style('vendors/datatables/datatables.bootstrap4.css'); ?>

    <?php echo style('vendors/datatables/Responsive-2.2.2/css/responsive.dataTables.min.css'); ?>

    <?php echo style('vendors/datatables/Select-1.3.0/css/select.dataTables.min.css'); ?>


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card-body">

        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    <?php echo e(__('labels.backend.guides.widgets.widgets')); ?> <small class="text-muted"><?php echo e(__('labels.backend.guides.widgets.active')); ?></small>
                </h4>
            </div><!--col-->

            <div class="col-sm-7">
                <?php echo $__env->make('backend.guides.widgets.includes.header-buttons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div><!--col-->
        </div><!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th><?php echo app('translator')->get('labels.backend.guides.widgets.table.icon'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.guides.widgets.table.title'); ?></th>
                            <th><?php echo app('translator')->get('labels.backend.guides.widgets.table.status'); ?></th>
                            <th><?php echo app('translator')->get('labels.general.actions'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="<?php echo e(asset($widget->getMedia('guide_widgets_backend')->first()->getUrl('thumb'))); ?>" alt="<?php echo e(ucwords($widget->title)); ?>" class="img-thumbnail"></td>
                                    <td><?php echo e(ucwords($widget->title)); ?></td>
                                    <td><?php echo $__env->make('backend.guides.widgets.includes.active', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                    <td><?php echo $__env->make('backend.guides.widgets.includes.actions', ['widget' => $widget], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div><!--col-->
        </div><!--row-->
        <div class="row">
            <div class="col-7">
                <div class="float-left">
                    <?php echo $widgets->total(); ?> <?php echo e(trans_choice('labels.backend.guides.widgets.table.total', $widgets->total())); ?>

                </div>
            </div><!--col-->

            <div class="col-5">
                <div class="float-right">
                    <?php echo $widgets->render(); ?>

                </div>
            </div><!--col-->
        </div><!--row-->
    </div><!--card-body-->
</div><!--card-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/buzzel_my/resources/views/backend/guides/widgets/index.blade.php ENDPATH**/ ?>
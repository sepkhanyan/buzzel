<aside class="aside-menu">

</aside>
<?php /**PATH /var/www/html/buzzel/resources/views/backend/includes/aside.blade.php ENDPATH**/ ?>